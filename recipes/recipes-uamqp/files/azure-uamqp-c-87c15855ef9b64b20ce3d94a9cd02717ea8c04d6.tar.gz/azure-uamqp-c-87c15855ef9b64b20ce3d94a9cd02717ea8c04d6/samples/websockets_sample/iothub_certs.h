// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef IOTHUB_CERTS_H
#define IOTHUB_CERTS_H

extern const char iothub_certs[];

#endif /* IOTHUB_CERTS_H */
