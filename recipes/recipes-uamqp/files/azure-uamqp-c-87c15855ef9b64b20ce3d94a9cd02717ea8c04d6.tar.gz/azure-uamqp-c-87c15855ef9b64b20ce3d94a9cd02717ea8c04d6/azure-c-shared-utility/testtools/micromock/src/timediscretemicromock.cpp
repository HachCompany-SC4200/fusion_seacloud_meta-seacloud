// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

/*defines*/
#include "stdafx.h"
#include "timediscretemicromock.h"

/*types*/
/*static variables*/
/*static functions*/

/*variable exports*/
std::vector<canPlay *> stims_base::allPlayers;

/*debug variables*/
UINT32 theTick;
UINT32 totalTicksPlayed;

/*function exports*/



