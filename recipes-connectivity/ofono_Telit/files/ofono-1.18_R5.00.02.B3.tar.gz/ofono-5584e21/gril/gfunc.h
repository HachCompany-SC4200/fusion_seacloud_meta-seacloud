/*
 *
 *  RIL library with GLib integration
 *
 *  Copyright (C) 2008-2011  Intel Corporation. All rights reserved.
 *  Copyright (C) 2012  Canonical Ltd.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License version 2 as
 *  published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#ifndef __GFUNC_H
#define __GFUNC_H

#include <glib.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*GRilDisconnectFunc)(gpointer user_data);
typedef void (*GRilReceiveFunc)(const unsigned char *data, gsize size,
							gpointer user_data);
typedef void (*GRilDebugFunc)(const char *str, gpointer user_data);
typedef void (*GRilSuspendFunc)(gpointer user_data);

#ifdef __cplusplus
}
#endif

#endif /* __GFUNC_H */
